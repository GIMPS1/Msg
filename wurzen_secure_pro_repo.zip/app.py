import os, sqlite3, secrets, time
from pathlib import Path
from typing import Optional
from fastapi import FastAPI, HTTPException, Request, Response
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel
from passlib.hash import bcrypt
from itsdangerous import URLSafeTimedSerializer, BadSignature, SignatureExpired

APP_NAME='Wurzen Secure'
DB=Path(os.getenv('WS_DB','wurzen_secure.db'))
SECRET=os.getenv('WS_SECRET_KEY','dev-change-me-'+secrets.token_hex(16))
ADMIN_USER=os.getenv('WS_ADMIN_USER','admin')
ADMIN_PASS=os.getenv('WS_ADMIN_PASS','change-this-admin-password')
serializer=URLSafeTimedSerializer(SECRET, salt='wurzen-secure-session')
app=FastAPI(title=APP_NAME)
app.add_middleware(CORSMiddleware, allow_origins=['*'], allow_credentials=True, allow_methods=['*'], allow_headers=['*'])

def db():
    con=sqlite3.connect(DB); con.row_factory=sqlite3.Row; return con

def init():
    con=db(); c=con.cursor()
    c.execute('create table if not exists users(id integer primary key, username text unique not null, password_hash text not null, display_name text, role text default "user", approved integer default 0, created_at integer)')
    c.execute('create table if not exists invites(code text primary key, created_by integer, used_by integer, used_at integer, created_at integer)')
    c.execute('create table if not exists threads(id integer primary key, title text, created_by integer, created_at integer)')
    c.execute('create table if not exists thread_members(thread_id integer, user_id integer, unique(thread_id,user_id))')
    c.execute('create table if not exists messages(id integer primary key, thread_id integer, sender_id integer, ciphertext text not null, iv text not null, created_at integer)')
    c.execute('select id from users where username=?',(ADMIN_USER,))
    if not c.fetchone():
        c.execute('insert into users(username,password_hash,display_name,role,approved,created_at) values(?,?,?,?,?,?)',(ADMIN_USER,bcrypt.hash(ADMIN_PASS),'Admin','admin',1,int(time.time())))
    con.commit(); con.close()
init()

class Register(BaseModel): username:str; password:str; display_name:Optional[str]=''; invite_code:Optional[str]=None
class Login(BaseModel): username:str; password:str
class ThreadIn(BaseModel): title:str='Secure chat'; member_usernames:list[str]
class MsgIn(BaseModel): thread_id:int; ciphertext:str; iv:str
class InviteIn(BaseModel): count:int=1

def current(request:Request):
    token=request.cookies.get('ws_session') or request.headers.get('x-ws-session')
    if not token: raise HTTPException(401,'Not signed in')
    try: uid=serializer.loads(token, max_age=60*60*24*30)
    except SignatureExpired: raise HTTPException(401,'Session expired')
    except BadSignature: raise HTTPException(401,'Invalid session')
    con=db(); u=con.execute('select id,username,display_name,role,approved from users where id=?',(uid,)).fetchone(); con.close()
    if not u or not u['approved']: raise HTTPException(403,'Account not approved')
    return dict(u)

def admin(request):
    u=current(request)
    if u['role']!='admin': raise HTTPException(403,'Admin only')
    return u

@app.get('/api/health')
def health(): return {'ok':True,'app':APP_NAME}
@app.post('/api/register')
def register(data:Register):
    if len(data.username)<3 or len(data.password)<8: raise HTTPException(400,'Username 3+ chars, password 8+ chars')
    con=db(); approved=0
    if data.invite_code:
        inv=con.execute('select code,used_by from invites where code=?',(data.invite_code.strip(),)).fetchone()
        if not inv or inv['used_by']: raise HTTPException(400,'Invalid or used invite')
        approved=1
    try:
        cur=con.execute('insert into users(username,password_hash,display_name,approved,created_at) values(?,?,?,?,?)',(data.username.strip().lower(),bcrypt.hash(data.password),data.display_name or data.username,approved,int(time.time())))
        if data.invite_code: con.execute('update invites set used_by=?,used_at=? where code=?',(cur.lastrowid,int(time.time()),data.invite_code.strip()))
        con.commit()
    except sqlite3.IntegrityError: raise HTTPException(400,'Username already exists')
    finally: con.close()
    return {'ok':True,'approved':bool(approved)}
@app.post('/api/login')
def login(data:Login,response:Response):
    con=db(); u=con.execute('select * from users where username=?',(data.username.strip().lower(),)).fetchone(); con.close()
    if not u or not bcrypt.verify(data.password,u['password_hash']): raise HTTPException(401,'Wrong username or password')
    if not u['approved']: raise HTTPException(403,'Account awaiting admin approval')
    token=serializer.dumps(u['id']); response.set_cookie('ws_session',token,httponly=True,samesite='lax',secure=False,max_age=60*60*24*30)
    return {'ok':True,'session':token,'user':{'username':u['username'],'display_name':u['display_name'],'role':u['role']}}
@app.post('/api/logout')
def logout(response:Response): response.delete_cookie('ws_session'); return {'ok':True}
@app.get('/api/me')
def me(request:Request): return current(request)
@app.get('/api/users')
def users(request:Request):
    current(request); con=db(); rows=con.execute('select username,display_name,role,approved from users where approved=1 order by display_name').fetchall(); con.close(); return [dict(r) for r in rows]
@app.post('/api/threads')
def create_thread(data:ThreadIn, request:Request):
    u=current(request); con=db(); ids=[u['id']]
    for name in data.member_usernames:
        r=con.execute('select id from users where username=? and approved=1',(name.strip().lower(),)).fetchone()
        if r: ids.append(r['id'])
    ids=sorted(set(ids)); cur=con.execute('insert into threads(title,created_by,created_at) values(?,?,?)',(data.title,u['id'],int(time.time())))
    tid=cur.lastrowid
    for uid in ids: con.execute('insert into thread_members(thread_id,user_id) values(?,?)',(tid,uid))
    con.commit(); con.close(); return {'id':tid,'title':data.title}
@app.get('/api/threads')
def list_threads(request:Request):
    u=current(request); con=db(); rows=con.execute('select t.id,t.title,t.created_at from threads t join thread_members m on m.thread_id=t.id where m.user_id=? order by t.id desc',(u['id'],)).fetchall(); con.close(); return [dict(r) for r in rows]
@app.get('/api/messages/{thread_id}')
def messages(thread_id:int, request:Request):
    u=current(request); con=db(); ok=con.execute('select 1 from thread_members where thread_id=? and user_id=?',(thread_id,u['id'])).fetchone()
    if not ok: raise HTTPException(403,'Not a member of this chat')
    rows=con.execute('select m.id,m.ciphertext,m.iv,m.created_at,u.username,u.display_name from messages m join users u on u.id=m.sender_id where m.thread_id=? order by m.id asc',(thread_id,)).fetchall(); con.close(); return [dict(r) for r in rows]
@app.post('/api/messages')
def send(data:MsgIn, request:Request):
    u=current(request); con=db(); ok=con.execute('select 1 from thread_members where thread_id=? and user_id=?',(data.thread_id,u['id'])).fetchone()
    if not ok: raise HTTPException(403,'Not a member of this chat')
    con.execute('insert into messages(thread_id,sender_id,ciphertext,iv,created_at) values(?,?,?,?,?)',(data.thread_id,u['id'],data.ciphertext,data.iv,int(time.time()))); con.commit(); con.close(); return {'ok':True}
@app.get('/api/admin/users')
def admin_users(request:Request):
    admin(request); con=db(); rows=con.execute('select id,username,display_name,role,approved,created_at from users order by id desc').fetchall(); con.close(); return [dict(r) for r in rows]
@app.post('/api/admin/approve/{uid}')
def approve(uid:int, request:Request): admin(request); con=db(); con.execute('update users set approved=1 where id=?',(uid,)); con.commit(); con.close(); return {'ok':True}
@app.post('/api/admin/invites')
def invites(data:InviteIn, request:Request):
    u=admin(request); con=db(); codes=[]
    for _ in range(max(1,min(data.count,20))):
        code='WS-'+secrets.token_urlsafe(12); codes.append(code); con.execute('insert into invites(code,created_by,created_at) values(?,?,?)',(code,u['id'],int(time.time())))
    con.commit(); con.close(); return {'codes':codes}
app.mount('/', StaticFiles(directory='static', html=True), name='static')
