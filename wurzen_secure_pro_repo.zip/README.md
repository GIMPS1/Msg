# Wurzen Secure

Private invite-only encrypted messaging MVP.

## What works
- Admin account and approval queue
- Invite-code registration
- Private user list
- Secure chat threads
- Client-side AES-GCM encryption before upload
- Server stores ciphertext only
- Mobile-first PWA styling
- APK build workflow using Capacitor

## Important honesty
This is a strong MVP, not a military-grade audited messenger. A production version needs formal security review, real key exchange, device identity, HTTPS, hardened deployment, backups, rate limiting and monitoring.

## Local run
```bash
pip install -r requirements.txt
uvicorn app:app --reload --port 8000
```
Open `http://127.0.0.1:8000`.

Default admin:

- username: `admin`
- password: `change-this-admin-password`

Change these environment variables before real use:

```bash
WS_SECRET_KEY="long-random-secret"
WS_ADMIN_USER="admin"
WS_ADMIN_PASS="a-strong-password"
```

## Phone access
Host the FastAPI app on an HTTPS domain. Users can install it from Chrome as a PWA.

## APK
The APK is a wrapper around the web app. In the APK, open **Server** and enter your hosted backend URL, for example:

```text
https://secure.yourdomain.com
```

Then sign in normally.
